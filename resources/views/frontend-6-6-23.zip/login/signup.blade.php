<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <title>MapBirdy Sign up</title>
    <link rel="shortcut icon" href="{{ asset('public/frontend/images/Favocon.png') }}" type="image/x-icon">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<style>
       body{
            background-color: rgb(1, 178, 255) !important;
            font-family: "Nunito Sans", sans-serif;
            font-size: 13px;
            color: #fff;
            margin-top:100px;
            
        }

        .he{

margin: 0;

font-size: 40px;
font-family: "Cloudy with a chance of love";
text-align: center;
color: #fff;

}
.pp{
    margin: 0px;
    margin-top:-20px;
    font-size: 14px;
    text-align: center;
    color: #fff;
    margin: top -10px;
}

.login {
            width: 100%;
            padding: 8px;
            text-align: center;
            justify-content: center;
            background-color: #390ec3;
            border: none;
            color: #fff;
            cursor: pointer;
            border-radius: 4px;
}
.buttons-container a:hover{
    text-decoration:none;
    color:white;
}


.butt {
            max-width: 400px;
            margin-top: 10px;
            margin-left:70px;
            margin-right:70px;
            padding:20px;
            margin-top:-10px
           
           
         
        }

        .buttons-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
            font-size: 15px;
            padding: 20px;
            

           

        }

        .google-btn,
        .facebook-btn {
            flex-grow: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            border-radius: 5px;
            text-decoration: none;
            width:120px;
        
            
        }

        .google-btn {
            background-color: #dc4e41;
            margin-right: 5px;
            float:left;
            padding:5px;
            
           
           
        }

        .facebook-btn {
            background-color: #3b5998;
            margin-left: 5px;
            float:right;
            
            
           
        }
        .bbg{
            width: 100%;
    padding: 8px;
    text-align: center;
    justify-content: center;
    background-color: #390ec3;
    border: none;
    color: #fff;
    cursor: pointer;
    font-size: 14px;
    border-radius: 4px;
        }

        .buttons-container {
    display: flex;
    justify-content: space-between;
    margin-bottom: 15px;
    font-size: 14px;
    padding: 1px;
}
.bbg:hover {
    background-color: #cde4ce;
    color: rgb(1, 178, 255);
}
.td{
    text-decoration:none;
}



</style>
</head>
<body>



  <div class="container">
    <div class="row justify-content-center">


      <div class="col-md-6">
      <h3 class="text-center mb-4 he">Map Birdy</h3>
        <p class="pp"> See what's happening in your area</p>
        <form class="form" action="{{url('/registration_post')}}" name="add_user" id="add_user" method="POST" >
        <h6>Sign up</h6>
        @csrf
        <form>
          <div class="form-group">
            
            <input type="text" class="form-control"  value="{{ old('name') }}" name="name"  placeholder="Username">
            <span class="text-danger"> @error('name') {{ $message }} @enderror </span>
            
          </div>
          <div class="form-group">
            
            <input type="email" class="form-control" value="{{ old('email') }}"  name="email"  placeholder="Email">
            <span class="text-danger"> @error('email') {{ $message }} @enderror </span>

          </div>
          <div class="form-group">
            
            <input class="form-control" id="password" type="password" name="new_password" placeholder="Password" value="" autocomplete="off">
            <span class="text-danger">@error('new_password') {{ $message }} @enderror</span>
          </div>

          <div class="form-group">
            
            <input class="form-control"  id="cnew_password" type="password" name="cnew_password" placeholder="Confirm Password" value="" autocomplete="off">
          </div>
          <div class="form-group">
          <button class="login bbg" type="submit">Sign up</button>

        </div>
        <p class="terms text-center">
            By signing up, you accept the <b>Term of Service</b> and
            <b>Privacy Policy.</b>
          </p>
          <div class="text-center">OR</div>

          <div class="butt">
        

        <div class="buttons-container">
            <a href="{{url('/g_login')}}" class="google-btn "onclick="loginWithGoogle()">
                <i class="bi bi-google" style="margin-right: 10px;"></i>
                Sign up with Google
            </a>

            <a href="{{url('/fb_login')}}" class="facebook-btn" onclick="loginWithFacebook()">
                <i class="bi bi-facebook" style="margin-right: 10px;"></i>
                Sign up with Facebook
            </a>
        </div>
    </div>

    
    <div class="account-exist text-center mt">
          <p>Already have an account? <a class="text-white td" href="{{ url('/') }}"><b>Sign In</b></a></p>
          <br />
          <a class="text-white td" href="{{url('/contact')}}"><b >Contact us</b></a>
          <p>Made in Sydney, Australia</p>
        </div>
        </form>
      </div>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
