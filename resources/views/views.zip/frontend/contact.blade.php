<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> NEIGHBOURHOOD - Contact Us</title>
   <link href="{{ asset('public/frontend/css/login.css') }}" rel="stylesheet" type="text/css">
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

</head>
    <body>
    <div class="container">
      <div class="logo">
        <h3>NEIGHBOURHOOD</h3>
        <p>Build by the community, for the community</p>
      </div>
      <p>Contact Us</p>
      <form action="{{url('/contact_post')}}" name="contact_post" id="contact_post" method="POST" >
      @csrf
      <div class="form-group">
<input type="text" name="name" value="{{ old('name') }}" placeholder="Name" class="form-control">
         <span class="text-danger"> @error('name') {{ $message }} @enderror </span>

        </div>
        <div class="form-group">
	    <input type="email" name="email" value="{{ old('email') }}" placeholder="Email" class="form-control">
        <span class="text-danger"> @error('email') {{ $message }} @enderror </span>

        </div>
        <div class="form-group">
            <textarea class="form-control" name="description" placeholder="Type message..." id="description" cols="30" rows="10"></textarea>
       <span class="text-danger">@error('description') {{ $message }} @enderror</span>
        </div>

        <div class="form-group">
          <button class="login" type="submit">Submit</button>
        </div>
        <div class="account-exist">
          <p>Don't have an account?
          <a class="registration" href="registration"><b>Sign Up</b></a></p>
          <!-- <br /> -->
          <p>Already have an account?
          <a class="registration" href="{{url('/')}}"><b>Sign In</b></a></p>
          <p>Made in Sydney, Australia</p>
        </div>
      </form>
    </div>

    </body>
</html>
