<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TBC - NEIGHBOURHOOD</title>

  <!-- Bootstrap CSS -->
  <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

  <style>
    .pagination a{
      color:#01b2ff;
      margin:3px;
      text-decoration:none;
font-weight:700;
    }
    .pagination {
    justify-content: center;
    }
    *{
        font-family: sans-serif;
        font-size: 12px;
    }
    #map {
      height: 100vh;
    }

    #card {
      position: absolute;
  top: 20px;
  left: 20px;
  right: 20px;
  bottom: 20px;
  max-width: 400px;
  margin: 0;
  background-color: rgba(255, 255, 255, 0.8);
  padding: 20px;
  border-radius: 8px;
  overflow: auto;

  scrollbar-width: none; /* Firefox */
  -ms-overflow-style: none; /* Internet Explorer 10+ */
  overflow: -moz-scrollbars-none; /* Firefox */
  overflow: -webkit-scrollbar-none;
    }
    #card::-webkit-scrollbar {
  display: none; /* Safari and Chrome */
}

    #vote-buttons,
    #comment-section {
      display: none;
    }

    .question {
      max-width: 80%;
      margin: 0 auto;
      text-align: center;
    }

    #main-question {
      border-radius: 8px;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 0px;
    }



    #toggle-button {
      margin-right: 2px;
    }
    #toggle-button:hover{
      background-color: rgb(247, 247, 247);
      font-size: 12px;
    }

    @media (max-width: 576px) {
      #card {
        top: 10px;
        left: 10px;
        right: 10px;
        bottom: 10px;
      }
    }
    .yes-btn{
      border-radius: 13px;
      border:none;
        background-color: rgb(1, 178, 255);
    }
    .no-btn{
        border-radius: 13px;
        border:none;
        background-color: rgb(206, 209, 210);
    }
    #search-btn{
        border-radius: 3px;
        background-color: rgb(1, 178, 255);
    }
    .logo{
        color: rgb(1, 178, 255);
        text-align: left;
        font-family: "Cloudy With a Chance of Love";
    }
    .logo-p{
        font-size: 12px;
        color: rgb(1, 178, 255);
        text-align: left;
    }
    .comment-wrapper {
      margin-top: 10px;
    max-width: 100%;
    min-height: 30px;
    max-height: 100px;
    overflow-y: scroll;
      background-color: #fff;
      padding: 5px;
      border-radius: 5px;
    }

    .user-comment {
      margin-bottom: 10px !important;
      background:white;
  border-radius: 5px;
  margin: 0;
  text-align: left;
  overflow-wrap: break-word;
    }

    .user-name {
        font-weight: bold;
    color: rgb(1, 178, 255);
    font-size: 12px;
    max-width: 100%;
    margin-left: 6px;
    }
    .date{
        font-size: 10px;
    }
    .input-group{
      background-color: rgb(247, 247, 247);
      border-radius: 8px;
    }
    .user-question{
      padding-top: 0%;
      padding-bottom: 0%;
    }
    .question {
    max-width: 80%;
    margin: 0 auto;
    text-align: left; /* Add this line */
  }
  .comments-area{
    background-color: #fff;
  }
  .comment-section{
    font-size: 12px;
  }
  .comment-section input{
    font-size: 12px;
  }
  .search-input{
    font-size: 12px;
  }
  .main-question{
    height: 40px;
  }
  .username-container {
  flex: 1;
  text-align: left;
}
#votes p{
  font-size: 10px;
  color: rgb(162, 161, 161);
}
.accordion-content {
      display: none;
      padding: 5px;
    }

    .accordion-toggle {
      cursor: pointer;
      font-weight: bold;
      color: rgb(1, 178, 255);;
    }
    .single-q{
      background-color: rgb(247, 247, 247); ;
    }
    .border_rl{
       border:none;
       border-radius:0px;

       border-top:1px solid #c1bdbd;
       border-bottom:1px solid #c1bdbd;
    }
    .p_voutes{
        font-size:8px;
    }
    .p_voutes span{
        font-size:8px;
    }
  </style>
  <style>
.dropbtn {
  background-color:  white;
  color:rgb(1, 178, 255);
  padding: 3px;
  border-radius:50px;
  font-size: 16px;
  border: none;
  transition:0.5s ease-in;
}

.dropdown {
  position: absolute;
  right:5%;
  top:10px;
  display: inline-block;
}

.dropdown-content {
  display: none;
    left: -32px;
  position: absolute;
  background-color:white;
  color: rgb(1, 178, 255);

  min-width: 100px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 6px 8px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {
    color:white;
  background-color: rgb(1, 178, 255);
}
</style>
</head>

<body>
<?php
$u_name = Auth::guard('users')->user()->name;
?>
  <div id="map"></div>

<div class="dropdown">
  <button class="dropbtn"><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
  <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
  <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
</svg></button>
  <div class="dropdown-content">
    <h5 href="#" style="color:black;font-weight: 700;text-transform: capitalize;border-bottom:1px solid black;padding:4px">{{ $u_name }}</h5>
    <a href="{{ route('contact') }}">Contact Us</a>
    <a href="{{ route('logout') }}">Sign Out</a>
  </div>
</div>
  <div id="card">
    <h3 class="logo">NEIGHBOURHOOD</h3>
    <p class="logo-p m-1">Build by the community, for the community</p>
    <form id="search_form" onsubmit="">
    <div class="input-group m-1 p-3 border_rl">
      <div class="input-group-prepend">
        <span class="input-group-text bg-light">
          <i style="font-size: 19px;" class="fas fa-map-marker-alt "></i>
        </span>
      </div>
      <!-- onchange="searcharea(this.value)" -->
      <input id="search-input" type="text" click="searcharea(this.value)" class="form-control bg-light" placeholder="Search">
      <div class="input-group-append">
        <button style="font-size: 12px;" id="search-btn" class="btn btn-primary">Search</button>
      </div>

    </div>
    </form>
       <p class="text-danger"> @error('area_name') {{ $message }} @enderror </p>
    <div class="input-group m-1 p-2">

      <input style="font-size: 12px;" type="text" id="questionSearch" class="form-control bg-light" placeholder="Search question ...">

    </div>
    <div class="accordion " id="accordionPanelsStayOpenExample">
  <?php
        $question = DB::table('question')->where('status', 1 )->orderby('listing_order')->get();

        ?>
        @foreach ($question as  $key => $questions)
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingOne">
      <button class="accordion-button  @if($key !=0) collapsed @endif " type="button" data-bs-toggle="collapse" data-bs-target="#question_no_{{ $questions->q_id }}"  @if($key ==0) aria-expanded="true" @else aria-expanded="false" @endif  aria-controls="question_no_{{ $questions->q_id }}">
     {{ $questions->question }}
      </button>
    </h2>
    <div id="question_no_{{ $questions->q_id }}" class="accordion-collapse collapse @if($key ==0) show @endif" aria-labelledby="panelsStayOpen-headingOne">
      <div class="accordion-body1">
      <div id="vote-buttons1" class="row m-1 p-2">
        <!--  -->


  <!-- <input type="radio" class="btn-check" name="options" id="option2" autocomplete="off" />
  <label class="btn btn-secondary" for="option2">Radio</label>

  <input type="radio" class="btn-check" name="options" id="option3" autocomplete="off" />
  <label class="btn btn-secondary" for="option3">Radio</label> -->

        <!--  -->
<div class="col-3 text-center">


@if($questions->opt1 !="")
<!-- <button  class="btn btn-primary no-btn">{{-- $questions->opt1 --}}</button> -->
 <input type="radio" value="1" class="btn-check" name="options" id="option_{{ $questions->q_id }}_1" autocomplete="off" checked />
  <label class="btn btn-secondary yes-btn" for="option1">{{ $questions->opt1 }}</label>
      <p class=" p_voutes"> <span>1</span> Votes <span>(1%)</span></p>
  @endif

</div>
<div class="col-3 text-center">
@if($questions->opt2 !="")
  <!-- <button  class="btn btn-primary no-btn">{{ $questions->opt2 }}</button> -->

      <input type="radio" value="2" class="btn-check" name="options" id="option_{{ $questions->q_id }}_2" autocomplete="off"   />
  <label class="btn btn-secondary no-btn" for="option1">{{ $questions->opt2 }}</label>
      <p class=" p_voutes"> <span>1</span> Votes <span>(1%)</span></p>
  @endif
</div>
<div class="col-3 text-center">
@if($questions->opt3 !="")
  <!-- <button  class="btn btn-primary yes-btn">{{ $questions->opt3 }}</button> -->
  <input type="radio" value="3" class="btn-check" name="options" id="option_{{ $questions->q_id }}_3" autocomplete="off"   />
  <label class="btn btn-secondary no-btn" for="option1">{{ $questions->opt3 }}</label>
      <p class=" p_voutes"> <span>1</span> Votes <span>(1%)</span></p>
  @endif
</div>
<div class="col-3 text-center">
@if($questions->opt4 !="")
  <!-- <button  class="btn btn-primary no-btn">{{ $questions->opt4 }}</button> -->
  <input type="radio" value="4" class="btn-check" name="options" id="option_{{ $questions->q_id }}_4" autocomplete="off"   />
  <label class="btn btn-secondary no-btn" for="option4">{{ $questions->opt4 }}</label>
      <p class=" p_voutes"> <span>1</span> Votes <span>(1%)</span></p>
  @endif
</div>
    </div>
    <form action="{{ route('comment_post') }}" method="post">
      <div class="form-group input-group m-0 p-2">
        <input type="hidden" value="{{ $questions->q_id }}" name="q_id">
        <input type="hidden"  class="area_name" name="area_name">


        @csrf
        <input class="form-control"  name="comment"  placeholder="Comment"/>

        <div class="input-group-append">
        <button style="font-size: 12px;"  class="btn btn-primary">Submit</button>
      </div>

      </div>
       <p class="text-danger"> @error('comment') {{ $message }} @enderror </p>
    </form>
    <div class="cont">


      <div  class="comment-wrapper container m-2">
      <?php
        $comments = DB::table('comments as c')->join('users as u', 'c.u_id', 'u.id')->orderby('c.created_at', 'DESC');
        if(1!=1){
            $comments->where('c.q_id', $questions->q_id);
        }
        $comments = $comments->where('c.q_id', $questions->q_id)->get();
    //    print_r($comments);
    //    die();
       ?>

        @foreach ($comments as  $key => $comment)
@if($comment)
      <div class="user-comment single-item">
          <div class="col-12 d-flex justify-content-between align-items-center">
            <div class="username-container">
              <span class="user-name">{{ $comment->name  }}</span>
            </div>
            <div>
            <i class="fa fa-x"></i>
              <span class="date">{{ date("d-m-Y" , strtotime($comment->created_at)) }}</span>
            </div>
          </div>
          <div>
            <span class=" m-2">{{  $comment->comment  }}</span>
          </div>
        </div>
        @endif()
        @endforeach()
        @foreach ($comments as  $key => $comment)
            @if($comment)
      <div class="user-comment single-item">
          <div class="col-12 d-flex justify-content-between align-items-center">
            <div class="username-container">
              <span class="user-name">{{ $comment->name  }}</span>
            </div>
            <div>
            <i class="fa fa-x"></i>
              <span class="date">{{ date("d-m-Y" , strtotime($comment->created_at)) }}</span>
            </div>
          </div>
          <div>
            <span class=" m-2">{{  $comment->comment  }}</span>
          </div>
        </div>
            @endif()
        @endforeach()


      </div>
      </div>
      <!--  -->
      </div>
    </div>
  </div>
  @endforeach()

  </div>

  <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
  <script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDRDEPG-Y1Ft3BmeLYzLZTnxgTvyDHxJVw&callback=initAutocomplete&libraries=places&v=weekly"
      defer
    ></script>
<!-- <script src="https://pagination.js.org/dist/2.6.0/pagination.js"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  <!-- Bootstrap JS -->
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
 <script>
(function($) {
	var pagify = {
		items: {},
		container: null,
		totalPages: 1,
		perPage: 3,
		currentPage: 0,
		createNavigation: function() {
			this.totalPages = Math.ceil(this.items.length / this.perPage);

			$('.pagination', this.container.parent()).remove();
			var pagination = $('<div class="pagination"></div>').append('<a class="nav prev disabled" data-next="false"><</a>');

			for (var i = 0; i < this.totalPages; i++) {
				var pageElClass = "page";
				if (!i)
					pageElClass = "page current";
				var pageEl = '<a class="' + pageElClass + '" data-page="' + (
				i + 1) + '">' + (
				i + 1) + "</a>";
				pagination.append(pageEl);
			}
			pagination.append('<a class="nav next" data-next="true">></a>');

			this.container.after(pagination);

			var that = this;
			$("body").off("click", ".nav");
			this.navigator = $("body").on("click", ".nav", function() {
				var el = $(this);
				that.navigate(el.data("next"));
			});

			$("body").off("click", ".page");
			this.pageNavigator = $("body").on("click", ".page", function() {
				var el = $(this);
				that.goToPage(el.data("page"));
			});
		},
		navigate: function(next) {
			// default perPage to 5
			if (isNaN(next) || next === undefined) {
				next = true;
			}
			$(".pagination .nav").removeClass("disabled");
			if (next) {
				this.currentPage++;
				if (this.currentPage > (this.totalPages - 1))
					this.currentPage = (this.totalPages - 1);
				if (this.currentPage == (this.totalPages - 1))
					$(".pagination .nav.next").addClass("disabled");
				}
			else {
				this.currentPage--;
				if (this.currentPage < 0)
					this.currentPage = 0;
				if (this.currentPage == 0)
					$(".pagination .nav.prev").addClass("disabled");
				}

			this.showItems();
		},
		updateNavigation: function() {

			var pages = $(".pagination .page");
			pages.removeClass("current");
			$('.pagination .page[data-page="' + (
			this.currentPage + 1) + '"]').addClass("current");
		},
		goToPage: function(page) {

			this.currentPage = page - 1;

			$(".pagination .nav").removeClass("disabled");
			if (this.currentPage == (this.totalPages - 1))
				$(".pagination .nav.next").addClass("disabled");

			if (this.currentPage == 0)
				$(".pagination .nav.prev").addClass("disabled");
			this.showItems();
		},
		showItems: function() {
			this.items.hide();
			var base = this.perPage * this.currentPage;
			this.items.slice(base, base + this.perPage).show();

			this.updateNavigation();
		},
		init: function(container, items, perPage) {
			this.container = container;
			this.currentPage = 0;
			this.totalPages = 1;
			this.perPage = perPage;
			this.items = items;
			this.createNavigation();
			this.showItems();
		}
	};

	// stuff it all into a jQuery method!
	$.fn.pagify = function(perPage, itemSelector) {
		var el = $(this);
		var items = $(itemSelector, el);

		// default perPage to 5
		if (isNaN(perPage) || perPage === undefined) {
			perPage = 3;
		}

		// don't fire if fewer items than perPage
		if (items.length <= perPage) {
			return true;
		}

		pagify.init(el, items, perPage);
	};
})(jQuery);

$(".container").pagify(6, ".single-item");

    $(document).ready(function(){
        const successCallback = (position) => {
  lat =position.coords.latitude;
  log =position.coords.longitude;
  initAutocomplete(lat,log)
};

const errorCallback = (error) => {
  console.log(error);
};
navigator.geolocation.getCurrentPosition(successCallback, errorCallback);
    });


$(document).ready(function(){
        const successCallback = (position) => {
//   console.log(position);
  lat =position.coords.latitude;
  log =position.coords.longitude;
  initAutocomplete(lat,log)
};

const errorCallback = (error) => {
//   console.log(error);
};

navigator.geolocation.getCurrentPosition(successCallback, errorCallback);
    });

function searcharea(val) {

    $(".area_name").val(val);
    console.log(val);
    // alert('func2')
}
function initAutocomplete(lat,log) {
  const map = new google.maps.Map(document.getElementById("map"), {
    center: { lat: lat, lng: log },
    zoom: 15,
    mapTypeId: "roadmap",
  });
  // Create the search box and link it to the UI element.
  const input = document.getElementById("search-input");
  const searchBox = new google.maps.places.SearchBox(input);

  // Bias the SearchBox results towards current map's viewport.
  map.addListener("bounds_changed", () => {
    searchBox.setBounds(map.getBounds());
  });
  let markers = [];
  // Listen for the event fired when the user selects a prediction and retrieve
  // more details for that place.
//   $location_input = $("#search-input");
//   autocomplete = new google.maps.places.Autocomplete($location_input.get(0));
//   google.maps.event.addListener(autocomplete, 'place_changed', function() {
//     var data = $("#search-input").val();
//     console.log(data)
//       $(".area_name").val(data);
//     return false;
//   });
  searchBox.addListener("places_changed", () => {
    const places = searchBox.getPlaces();

    if (places.length == 0) {
      return;
    }
    // Clear out the old markers.
    markers.forEach((marker) => {
      marker.setMap(null);
    });
    markers = [];
    // For each place, get the icon, name and location.
    const bounds = new google.maps.LatLngBounds();

    places.forEach((place) => {
      if (!place.geometry || !place.geometry.location) {
        console.log("Returned place contains no geometry");
        // console.log(place.name);
        return;
      }


    //   $(".area_name").val(place.name);
    //   console.log(place.name);
    //   console.log(place.geometry.location);
      const icon = {
        url: place.icon,
        size: new google.maps.Size(71, 71),
        origin: new google.maps.Point(0, 0),
        anchor: new google.maps.Point(17, 34),
        scaledSize: new google.maps.Size(25, 25),
      };

      // Create a marker for each place.
      markers.push(
        new google.maps.Marker({
          map,
          icon,
          title: place.name,
          position: place.geometry.location,
        })
      );
      if (place.geometry.viewport) {
        // Only geocodes have viewport.
        bounds.union(place.geometry.viewport);
      } else {
        bounds.extend(place.geometry.location);
      }
    });

    map.fitBounds(bounds);

//     console.log(places[0]);
//   console.log(bounds);
    //   console.log(places[0].name);
    //   console.log(places[0].formatted_address);
    //   $(".area_name").val(places[0].formatted_address);

    // console.log("places[0].formatted_address");
  });

}
window.initAutocomplete = initAutocomplete;

    @if (Session::get('msg'))
$(document).ready(function(){
    var txt ="<?php echo Session::get('msg');?> ";
    var alert ="<?php echo Session::get('alert');?>";
    swal("",txt, alert)
}); @endif

    $(document).ready(function(){
  $("#questionSearch").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $(".accordion-button").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

</body>
</html>
