<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TBC - Forgot Password</title>
   <link href="{{ asset('public/frontend/css/login.css') }}" rel="stylesheet" type="text/css">
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
    <body>
    <div class="container">
      <div class="logo">
        <h3>NEIGHBOURHOOD</h3>
        <p>Build by the community, for the community</p>
      </div>
      <p>Forgot Password</p>
      <form id="login-form" action="{{ url('forgotPasswordProcess') }}" method="post">
      @csrf
        <div class="form-group">
        <input type="email" class="form-control" name="email" placeholder="Email" value="{{ old('email') }}" >
                                        <span class="text-danger">@error('email'){{ $message }}@enderror</span>

        </div>

        <div class="form-group">
          <button class="login" type="submit">Submit</button>

        </div>
        <div class="text">_______ or _______</div>
        <div class="form-group social-login">
          <a href="{{url('/gcustomer_login')}}" class="google" onclick="loginWithGoogle()"><i class="bi bi-google" style="margin-right: 10px;"></i>Sign Up with Google</a>
          <a href="{{url('/fb_login')}}" class="facebook" onclick="loginWithFacebook()"><i class="bi bi-facebook" style="margin-right: 10px;"></i> Sign Up with  Facebook </a>
        </div>
        <div class="account-exist">
          <p>Don't have an account?
          <a class="registration" href="registration"><b>Sign Up</b></a></p>
          <!-- <br /> -->
          <p>Already have an account?
          <a class="registration" href="{{url('/')}}"><b>Sign In</b></a></p>
          <a class="" href="{{url('/contact')}}"><b>Contact us</b></a>
        </div>
        <p>Made in Sydney, Australia</p>
      </form>
    </div>
    </body>
</html>
