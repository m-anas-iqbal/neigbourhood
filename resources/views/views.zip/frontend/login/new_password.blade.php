<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TBC - New Password</title>
   <link href="{{ asset('public/frontend/css/login.css') }}" rel="stylesheet" type="text/css">

</head>
    <body>
    <div class="container">
      <div class="logo">
        <h3>NEIGHBOURHOOD</h3>
        <p>Build by the community, for the community</p>
      </div>
      <p>New Password</p>
      <form id="login-form" action="{{ url('newPasswordProcess') }}" method="post">
      <input type='hidden' name="np_code" value="{{Request::segment(2)}}"/>
      @csrf
        <div class="form-group">
        <input class="form-control password" id="password" class="block mt-1 w-full" type="password" name="new_password" placeholder="Change Password" value="{{ old('password') }}" autocomplete='off'/>

          <span class="text-danger">@error('new_password'){{ $message }}@enderror</span>

        </div>
        <div class="form-group">
        <input class="form-control password" id="password" class="block mt-1 w-full" type="password" name="cnew_password" placeholder="Confirm New Password" value="{{ old('password') }}" autocomplete='off'/>

        </div>

        <div class="form-group">
          <button class="login" type="submit">Update Password</button>
        </div>

        <p>Made in Sydney, Australia</p>
      </form>
    </div>

    </body>
</html>
