<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> NEIGHBOURHOOD - Sign Up</title>
   <link href="{{ asset('public/frontend/css/login.css') }}" rel="stylesheet" type="text/css">
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

</head>
    <body>
    <div class="container">
      <div class="logo">
        <h3>NEIGHBOURHOOD</h3>
        <p>Build by the community, for the community</p>
      </div>
      <p>Sign Up</p>
      <form id="login-form" action="{{url('/registration_post')}}" name="add_user" id="add_user" method="POST" >
      @csrf
      <div class="form-group">
<input type="text" name="name" value="{{ old('name') }}" placeholder="Username" class="form-control">
         <span class="text-danger"> @error('name') {{ $message }} @enderror </span>

        </div>
        <div class="form-group">
	    <input type="email" name="email" value="{{ old('email') }}" placeholder="Email" class="form-control">
        <span class="text-danger"> @error('email') {{ $message }} @enderror </span>

        </div>
        <div class="form-group">
          <input class="form-control" id="password" type="password" name="new_password" placeholder="Password" value="" autocomplete="off">
       <span class="text-danger">@error('new_password') {{ $message }} @enderror</span>


        </div>
        <div class="form-group">
          <input class="form-control" id="cnew_password" type="password" name="cnew_password" placeholder="Confirm Password" value="" autocomplete="off">

        </div>

        <div class="form-group">
          <button class="login" type="submit">Sign Up</button>
          <p class="terms">
            By signing up, you accept the <b>Term of Service</b> and
            <b>Privacy Policy.</b>
          </p>
        </div>
        <div class="text">_______ or _______</div>
        <div class="form-group social-login">
          <a href="{{url('/gcustomer_login')}}" class="google" onclick="loginWithGoogle()"><i class="bi bi-google" style="margin-right: 10px;"></i>Sign Up with Google</a>
          <a href="{{url('/fb_login')}}" class="facebook" onclick="loginWithFacebook()"><i class="bi bi-facebook" style="margin-right: 10px;"></i> Sign Up with  Facebook </a>
        </div>
        <div class="account-exist">
          <p>Already have an account?</p>
          <a class="" href="{{ url('/') }}"><b>Sign In</b></a>
          <br />
          <a class="" href="{{url('/contact')}}"><b>Contact us</b></a>
          <p>Made in Sydney, Australia</p>
        </div>
      </form>
    </div>

    </body>
</html>
