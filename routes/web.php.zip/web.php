<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\GoogleController;
use App\Http\Controllers\FacebookController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

//================ clear cache ================= //
 //Clear route cache
 Route::get('/route-cache', function() {
    \Artisan::call('route:cache');
    return 'Routes cache cleared';
});

//Clear config cache
Route::get('/config-cache', function() {
    \Artisan::call('config:cache');
    return 'Config cache cleared';
});

// Clear application cache
Route::get('/clear-cache', function() {
    \Artisan::call('cache:clear');
    return 'Application cache cleared';
});

// Clear view cache
Route::get('/view-clear', function() {
    \Artisan::call('view:clear');
    return 'View cache cleared';
});

// Clear cache using reoptimized class
Route::get('/optimize-clear', function() {
    \Artisan::call('optimize:clear');
    return 'View cache cleared';
});

//================ clear cache  end ================= //

Route::get('/', function () {
    if (Auth::guard('users')->check()) {
        return  redirect('/dashboard');

  }else{
     return view('frontend.login.login');
  }

})->name('login');
Route::post('/login_post', [HomeController::class, 'login_post'])->name('login_post');
Route::get('/logout', [HomeController::class, 'logout'])->name('logout');
Route::get('/contact', function () {

    return view('frontend.contact');
  

})->name('contact');
Route::post('/contact_post', [HomeController::class, 'contact_post'])->name('contact_post');
Route::post('/comment_post', [HomeController::class, 'comment_post'])->name('comment_post');

Route::get('/registration', function () {
    if (Auth::guard('users')->check()) {
        return  redirect('/dashboard');

  }else{
    return view('frontend.login.signup');
  }
});
Route::post('/registration_post', [HomeController::class, 'registration_post'])->name('registration_post');

// facebook login
Route::get('/fb_login', [FacebookController::class, 'fb_login']);
Route::get('/fb/callback', [FacebookController::class, 'callback']);

Route::get('privacy_policy', [FacebookController::class, 'privacy_policy']);
Route::get('deletionurl', [FacebookController::class, 'deletionurl']);


//google login
 Route::get('/gcustomer_login', [GoogleController::class, 'customer_login']);
Route::get('/g_login', [GoogleController::class, 'g_login']);
// Route::get('/gmail/callback', [GoogleController::class, 'callback']);
Route::get('/gmail/callback', [GoogleController::class, 'customer_handleGoogleCallback']);
Route::get('registrationEmailVerification/{code}', [HomeController::class, 'registrationEmailVerification']);




//forgotPasswordProcess
Route::get('/forgotPassword', function () {
    if (Auth::guard('users')->check()) {
        return  redirect('/dashboard');

  }else{
    return view('frontend.login.forgot_password');
  }
});
Route::post('/forgotPasswordProcess', [HomeController::class, 'forgotPasswordProcess']);

//newPasswordProcess
Route::get('newPassword/{pass}', function () {
    if (Auth::guard('users')->check()) {
        return  redirect('/dashboard');

  }else{
    return view('frontend.login.new_password');
  }
});
Route::post('newPasswordProcess/', [HomeController::class, 'newPasswordProcess']);

Route::middleware(['auth:users', 'PreventBackHistory'])->group(function () {
    //Route::get('/dashboard', function () {return view('frontend.index');});
    Route::get('/dashboard', [HomeController::class, 'dashboard']);
});
Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('/logout', [AdminController::class, 'logout'])->name('logout');
    Route::get('/',  function () {
        if (Auth::guard('admin')->check()) {
            return  redirect('/admin/dashboard');

      }else{
        return view('admin.login');
      }
    })->name('login');
    Route::post('/login_post', [AdminController::class, 'login_post']);
    Route::middleware(['auth:admin', 'PreventBackHistory'])->group(function () {
        Route::get('/dashboard', function () {return view('admin.index');});
        // questions
        Route::get('/question', function () {return view('admin.question.question');});
        Route::get('/addquestion', function () {return view('admin.question.add_question');});
        Route::post('/addquestion_post', [AdminController::class, 'addquestion_post']);
        Route::get('/editquestion/{id}', function () {return view('admin.question.edit_question');});
        Route::post('/editquestion_post',  [AdminController::class, 'editquestion_post']);
        Route::post('/delquestion_post', [AdminController::class, 'delquestion_post']);

        //comments|answers
        Route::get('/comment', function () {return view('admin.question.answer');});
        Route::post('/delcomment',[AdminController::class, 'delcomment']);
        //comments|answers
        Route::get('/profile', function () {return view('admin.profile');});
        Route::post('/profile_post',[AdminController::class, 'profile_post']);
    });
});
